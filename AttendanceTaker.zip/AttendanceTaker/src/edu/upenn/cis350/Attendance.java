package edu.upenn.cis350;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Attendance extends Activity{

	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.attendance);
    }
	
    public void onEditActivitiesClick(View view) {
    	Intent i = new Intent(this, AddActivity.class);
    	startActivityForResult(i, AttendanceTakerActivity.ACTIVITY_AddActivity);
    }
	
}
